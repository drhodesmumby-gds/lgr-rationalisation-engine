#!/usr/bin/env python3
"""Generate PowerPoint from slides.html content (v1, 19 slides)."""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
import os

SLIDE_DIR = os.path.dirname(os.path.abspath(__file__))
IMG_DIR = os.path.join(SLIDE_DIR, 'img')

# GDS colours
BLACK = RGBColor(0x0B, 0x0C, 0x0C)
BLUE = RGBColor(0x1D, 0x70, 0xB8)
RED = RGBColor(0xD4, 0x35, 0x1C)
GREEN = RGBColor(0x00, 0x70, 0x3C)
PURPLE = RGBColor(0x4C, 0x2C, 0x92)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GREY = RGBColor(0xF3, 0xF2, 0xF1)
MID_GREY = RGBColor(0xB1, 0xB4, 0xB6)
DARK_GREY = RGBColor(0x50, 0x5A, 0x5F)

# Tag colours
TAG_BLUE_BG = RGBColor(0xD2, 0xE2, 0xF1)
TAG_BLUE_FG = RGBColor(0x00, 0x30, 0x78)
TAG_GREEN_BG = RGBColor(0xCC, 0xE2, 0xD8)
TAG_GREEN_FG = RGBColor(0x00, 0x5A, 0x30)
TAG_RED_BG = RGBColor(0xF6, 0xD7, 0xD2)
TAG_RED_FG = RGBColor(0x94, 0x25, 0x14)
TAG_PURPLE_BG = RGBColor(0xDB, 0xD5, 0xE9)
TAG_PURPLE_FG = RGBColor(0x3D, 0x23, 0x75)
TAG_GREY_BG = RGBColor(0xE8, 0xE8, 0xE8)
TAG_GREY_FG = RGBColor(0x38, 0x3F, 0x43)

# Slide dimensions (widescreen 16:9)
SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)

prs = Presentation()
prs.slide_width = SLIDE_W
prs.slide_height = SLIDE_H

# Use blank layout
blank_layout = prs.slide_layouts[6]


def add_shape(slide, left, top, width, height, fill=None, line_color=None, line_width=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, height)
    shape.line.fill.background()
    if fill:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill
    else:
        shape.fill.background()
    if line_color:
        shape.line.color.rgb = line_color
        shape.line.width = line_width or Pt(1)
    return shape


def add_textbox(slide, left, top, width, height):
    return slide.shapes.add_textbox(left, top, width, height)


def set_text(tf, text, font_size=18, bold=False, color=BLACK, alignment=PP_ALIGN.LEFT):
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.alignment = alignment
    return p


def add_paragraph(tf, text, font_size=18, bold=False, color=BLACK, alignment=PP_ALIGN.LEFT, space_before=0, space_after=0):
    p = tf.add_paragraph()
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.alignment = alignment
    if space_before:
        p.space_before = Pt(space_before)
    if space_after:
        p.space_after = Pt(space_after)
    return p


def add_run(paragraph, text, font_size=None, bold=None, color=None, italic=None):
    run = paragraph.add_run()
    run.text = text
    if font_size:
        run.font.size = Pt(font_size)
    if bold is not None:
        run.font.bold = bold
    if color:
        run.font.color.rgb = color
    if italic is not None:
        run.font.italic = italic
    return run


def add_header_bar(slide, slide_num, total=19):
    """Add the GOV.UK-style black header bar with blue bottom border."""
    # Black bar
    add_shape(slide, 0, 0, SLIDE_W, Inches(0.65), fill=BLACK)
    # Blue border
    add_shape(slide, 0, Inches(0.65), SLIDE_W, Inches(0.06), fill=BLUE)

    # Title text
    tb = add_textbox(slide, Inches(0.5), Inches(0.12), Inches(8), Inches(0.45))
    set_text(tb.text_frame, 'GOV.UK  |  LGR Rationalisation Engine', font_size=14, bold=True, color=WHITE)

    # Slide number
    tb = add_textbox(slide, Inches(11), Inches(0.12), Inches(2), Inches(0.45))
    set_text(tb.text_frame, f'{slide_num} / {total}', font_size=12, color=MID_GREY, alignment=PP_ALIGN.RIGHT)


def add_blue_top_heading(slide, text, top=Inches(0.95)):
    """Add heading with blue top border."""
    add_shape(slide, Inches(0.5), top, Inches(12.3), Inches(0.04), fill=BLUE)
    tb = add_textbox(slide, Inches(0.5), top + Inches(0.15), Inches(12.3), Inches(0.5))
    set_text(tb.text_frame, text, font_size=28, bold=True, color=BLACK)
    return top + Inches(0.75)


def add_lead_text(slide, text, top, left=Inches(0.5), width=Inches(5.8)):
    tb = add_textbox(slide, left, top, width, Inches(1))
    tf = tb.text_frame
    tf.word_wrap = True
    set_text(tf, text, font_size=14, color=DARK_GREY)
    return tb


def add_bullet_list(slide, items, left, top, width, height):
    """Add a bullet list. Items are (bold_prefix, rest_text) tuples or plain strings."""
    tb = add_textbox(slide, left, top, width, height)
    tf = tb.text_frame
    tf.word_wrap = True

    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.space_before = Pt(4)
        p.space_after = Pt(4)

        if isinstance(item, tuple):
            bold_text, rest = item
            run = p.add_run()
            run.text = bold_text
            run.font.size = Pt(12)
            run.font.bold = True
            run.font.color.rgb = BLACK
            run = p.add_run()
            run.text = f' \u2014 {rest}'
            run.font.size = Pt(12)
            run.font.color.rgb = BLACK
        else:
            run = p.add_run()
            run.text = item
            run.font.size = Pt(12)
            run.font.color.rgb = BLACK

        # Blue bullet square
        p.level = 0
    return tb


def add_image_safe(slide, img_name, left, top, width=None, height=None):
    """Add image if it exists."""
    img_path = os.path.join(IMG_DIR, img_name)
    if os.path.exists(img_path):
        kwargs = {}
        if width:
            kwargs['width'] = width
        if height:
            kwargs['height'] = height
        if not kwargs:
            kwargs['width'] = Inches(5.5)
        return slide.shapes.add_picture(img_path, left, top, **kwargs)
    return None


def add_quote(slide, text, cite, left, top, width, border_color=BLUE):
    """Add a quote block."""
    # Border
    add_shape(slide, left, top, Inches(0.04), Inches(1.2), fill=border_color)
    # Background
    add_shape(slide, left + Inches(0.04), top, width - Inches(0.04), Inches(1.2), fill=LIGHT_GREY)
    # Text
    tb = add_textbox(slide, left + Inches(0.2), top + Inches(0.1), width - Inches(0.4), Inches(0.8))
    tf = tb.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = f'\u201c{text}\u201d'
    run.font.size = Pt(13)
    run.font.italic = True
    run.font.color.rgb = BLACK
    p = tf.add_paragraph()
    run = p.add_run()
    run.text = f'\u2014 {cite}'
    run.font.size = Pt(10)
    run.font.color.rgb = DARK_GREY
    run.font.italic = False
    return tb


def add_tag(slide, text, left, top, bg_color, fg_color, width=None):
    """Add a colored tag."""
    if width is None:
        width = Inches(max(1.2, len(text) * 0.11))
    shape = add_shape(slide, left, top, width, Inches(0.28), fill=bg_color)
    shape.text_frame.word_wrap = False
    p = shape.text_frame.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = text.upper()
    run.font.size = Pt(8)
    run.font.bold = True
    run.font.color.rgb = fg_color
    shape.text_frame.margin_top = Pt(2)
    shape.text_frame.margin_bottom = Pt(2)
    return shape


# ============================================================
# SLIDE 1: Title
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_shape(slide, 0, 0, SLIDE_W, SLIDE_H, fill=BLACK)

# Blue bar
add_shape(slide, Inches(1), Inches(2.2), Inches(1), Inches(0.06), fill=BLUE)

# Title
tb = add_textbox(slide, Inches(1), Inches(2.5), Inches(10), Inches(1.5))
tf = tb.text_frame
set_text(tf, 'LGR Rationalisation', font_size=44, bold=True, color=WHITE)
add_paragraph(tf, 'Engine', font_size=44, bold=True, color=WHITE)

# Subtitle
tb = add_textbox(slide, Inches(1), Inches(4.2), Inches(10), Inches(0.6))
set_text(tb.text_frame, 'Decision-support tooling for IT estate transitions', font_size=20, color=MID_GREY)

# Meta
tb = add_textbox(slide, Inches(1), Inches(5.0), Inches(6), Inches(0.4))
set_text(tb.text_frame, 'GDS Local  \u00b7  April 2026', font_size=13, color=DARK_GREY)

tb = add_textbox(slide, Inches(1), Inches(5.4), Inches(6), Inches(0.4))
set_text(tb.text_frame, 'Experimental prototype  \u00b7  Internal discussion', font_size=13, color=RGBColor(0x77, 0x77, 0x77))


# ============================================================
# SLIDE 2: The Problem
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 2)
body_top = add_blue_top_heading(slide, 'The problem')

add_lead_text(slide, '21 LGR programmes are merging councils into new unitary authorities. Every programme must rationalise its combined IT estate.', body_top)

# Metric cards
card_top = body_top + Inches(0.7)
for i, (num, label) in enumerate([('21', 'LGR programmes'), ('2\u20137', 'Councils per merger')]):
    left = Inches(0.5 + i * 2.2)
    shape = add_shape(slide, left, card_top, Inches(2), Inches(0.8), line_color=MID_GREY)
    tb = add_textbox(slide, left + Inches(0.15), card_top + Inches(0.05), Inches(1.7), Inches(0.45))
    set_text(tb.text_frame, num, font_size=28, bold=True, color=RED)
    tb = add_textbox(slide, left + Inches(0.15), card_top + Inches(0.45), Inches(1.7), Inches(0.3))
    set_text(tb.text_frame, label, font_size=10, color=DARK_GREY)

# Bullet points
items = [
    ('Hundreds of systems per programme', 'overlapping contracts, shared services, and monolithic data'),
    ('No standard tooling', 'councils using spreadsheets with inconsistent formats and incomplete data'),
    ('Contract notice deadlines', 'spread across separate councils risk being missed without a consolidated view'),
    ('Different audiences', 'boards, commercial teams, architects need different views of the same estate'),
]
add_bullet_list(slide, items, Inches(0.5), card_top + Inches(1.0), Inches(5.8), Inches(3))

# Quotes
add_quote(slide, 'Migrating data is eye-wateringly expensive.',
          'Local Digital LGR Playbook, Section 5: Disaggregating Services and Data',
          Inches(6.8), body_top + Inches(0.3), Inches(5.8))

add_quote(slide, 'Councils must have a clear shared view of the systems across their area, including contract end dates and notice periods.',
          'Local Digital LGR Playbook, Section 3: Collaboration and Baselining',
          Inches(6.8), body_top + Inches(1.8), Inches(5.8), border_color=RED)


# ============================================================
# SLIDE 3: The Idea (Hero)
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_shape(slide, 0, 0, SLIDE_W, SLIDE_H, fill=BLACK)
add_header_bar(slide, 3)

# Central text
tb = add_textbox(slide, Inches(1.5), Inches(1.8), Inches(10), Inches(1.2))
tf = tb.text_frame
set_text(tf, 'One taxonomy. One matrix.', font_size=32, bold=True, color=WHITE, alignment=PP_ALIGN.CENTER)
add_paragraph(tf, 'Every perspective.', font_size=32, bold=True, color=WHITE, alignment=PP_ALIGN.CENTER)

# Three concepts
concepts = [
    ('Reconcile', 'Map systems across councils to a shared function taxonomy'),
    ('Analyse', 'See every function, system, and successor in one decision matrix'),
    ('Focus', 'Filter by audience \u2014 boards, commercial teams, architects'),
]
for i, (title, desc) in enumerate(concepts):
    left = Inches(1.5 + i * 3.8)
    tb = add_textbox(slide, left, Inches(3.6), Inches(3.2), Inches(0.4))
    set_text(tb.text_frame, title, font_size=16, bold=True, color=WHITE, alignment=PP_ALIGN.CENTER)
    tb = add_textbox(slide, left, Inches(4.1), Inches(3.2), Inches(0.8))
    tf = tb.text_frame
    tf.word_wrap = True
    set_text(tf, desc, font_size=12, color=MID_GREY, alignment=PP_ALIGN.CENTER)


# ============================================================
# SLIDE 4: What This Tool Does
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 4)
body_top = add_blue_top_heading(slide, 'What this tool does')

add_lead_text(slide, 'A browser-based analysis tool that ingests council IT architecture data, reconciles it against a shared taxonomy, and renders a configurable decision-support matrix.', body_top)

items = [
    ('Taxonomy reconciliation', 'maps every system to the ESD Standard Function Taxonomy (176 functions)'),
    ('Transition modelling', 'models which predecessor councils feed into which successor authorities'),
    ('8 analytical signals', 'factual observations about contract urgency, data complexity, vendor density, and more'),
    ('3 persona views', 'same data, different emphasis for Executive boards, Commercial teams, and Enterprise Architects'),
    ('Import wizard', 'accepts CSV, Excel, clipboard paste, or guided manual entry'),
]
add_bullet_list(slide, items, Inches(0.5), body_top + Inches(0.7), Inches(5.8), Inches(3.5))

add_image_safe(slide, '06-dashboard-executive.png', Inches(6.8), body_top + Inches(0.2), width=Inches(5.8))


# ============================================================
# SLIDE 5: How It Works
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 5)
body_top = add_blue_top_heading(slide, 'How it works')

# Pipeline steps
steps = [
    ('1. Ingest', 'Upload council architectures', RGBColor(0xD2, 0xE2, 0xF1), TAG_BLUE_FG),
    ('1.5 Transition', 'Define successors & vesting date', TAG_PURPLE_BG, TAG_PURPLE_FG),
    ('2. Baselining', 'Reconcile against ESD taxonomy', TAG_GREEN_BG, TAG_GREEN_FG),
    ('3. Dashboard', 'Analysis matrix & signals', BLACK, WHITE),
]
step_width = Inches(2.8)
arrow_width = Inches(0.4)
for i, (title, subtitle, bg, fg) in enumerate(steps):
    left = Inches(0.5 + i * 3.2)
    shape = add_shape(slide, left, body_top + Inches(0.1), step_width, Inches(0.7), fill=bg)
    tf = shape.text_frame
    tf.word_wrap = True
    tf.margin_top = Pt(4)
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = title
    run.font.size = Pt(11)
    run.font.bold = True
    run.font.color.rgb = fg
    p2 = tf.add_paragraph()
    p2.alignment = PP_ALIGN.CENTER
    run2 = p2.add_run()
    run2.text = subtitle
    run2.font.size = Pt(8)
    run2.font.color.rgb = fg

    if i < 3:
        tb = add_textbox(slide, left + step_width, body_top + Inches(0.15), arrow_width, Inches(0.5))
        set_text(tb.text_frame, '\u203a', font_size=20, color=MID_GREY, alignment=PP_ALIGN.CENTER)

# Three screenshots
img_top = body_top + Inches(1.2)
screenshots = [
    ('03-stage1-files.png', 'Stage 1: Six council files staged'),
    ('04-transition-config.png', 'Stage 1.5: Successor authorities auto-detected'),
    ('05-baselining.png', 'Stage 2: 10 cross-council collisions identified'),
]
for i, (img, caption) in enumerate(screenshots):
    left = Inches(0.5 + i * 4.2)
    add_image_safe(slide, img, left, img_top, width=Inches(3.8))
    tb = add_textbox(slide, left, img_top + Inches(3.2), Inches(3.8), Inches(0.4))
    set_text(tb.text_frame, caption, font_size=9, color=DARK_GREY, alignment=PP_ALIGN.CENTER)


# ============================================================
# SLIDE 6: The Analysis Matrix
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 6)
body_top = add_blue_top_heading(slide, 'The analysis matrix')

add_lead_text(slide, 'Each row is an ESD function. Columns show systems per successor authority. Rationalisation patterns are classified automatically.', body_top, width=Inches(12))

# Tags
tag_top = body_top + Inches(0.6)
tags = [
    ('Inherit as-is', TAG_GREEN_BG, TAG_GREEN_FG),
    ('Choose & consolidate', TAG_BLUE_BG, TAG_BLUE_FG),
    ('Extract & partition', TAG_RED_BG, TAG_RED_FG),
    ('Extract, partition & consolidate', TAG_PURPLE_BG, TAG_PURPLE_FG),
]
tag_left = Inches(0.5)
for text, bg, fg in tags:
    w = Inches(max(1.4, len(text) * 0.12))
    add_tag(slide, text, tag_left, tag_top, bg, fg, width=w)
    tag_left += w + Inches(0.15)

# Tier tags
tier_tags = [
    ('Tier 1 \u00b7 Day 1 Critical', RGBColor(0xFC, 0xE4, 0xE4), TAG_RED_FG),
    ('Tier 2 \u00b7 High Priority', RGBColor(0xFE, 0xF3, 0xCD), RGBColor(0x85, 0x64, 0x04)),
    ('Tier 3 \u00b7 Post-Day 1', TAG_GREY_BG, TAG_GREY_FG),
]
tag_left = Inches(8.5)
for text, bg, fg in tier_tags:
    w = Inches(1.8)
    add_tag(slide, text, tag_left, tag_top, bg, fg, width=w)
    tag_left += w + Inches(0.1)

add_image_safe(slide, '07-matrix-rows.png', Inches(0.5), tag_top + Inches(0.5), width=Inches(12.3))


# ============================================================
# SLIDE 7: Signal System
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 7)
body_top = add_blue_top_heading(slide, 'Signal system \u2014 factual, not prescriptive')

add_lead_text(slide, 'Eight analytical signals surface factual observations about each system. Users adjust emphasis \u2014 the tool does not prescribe decisions.', body_top)

# Signal table
signals = [
    ('Contract urgency', 'Months until notice trigger; classified by vesting zone'),
    ('User volume', 'Relative user counts; anchor system detection'),
    ('Monolithic data', 'Systems with undivided data or ERP flags'),
    ('Data portability', 'Vendor lock-in risk (Low / Medium / High)'),
    ('Vendor density', 'Same vendor across multiple councils for a function'),
    ('On-premise', 'Systems not yet cloud-hosted'),
    ('TCoP alignment', 'Assessment against 5 Technology Code of Practice points'),
    ('Shared service', 'Cross-council shared services; boundary crossing detection'),
]

table_top = body_top + Inches(0.8)
rows = len(signals) + 1
cols = 2
table = slide.shapes.add_table(rows, cols, Inches(0.5), table_top, Inches(6), Inches(3.2)).table
table.columns[0].width = Inches(1.8)
table.columns[1].width = Inches(4.2)

# Header row
for j, header in enumerate(['Signal', 'What it measures']):
    cell = table.cell(0, j)
    cell.fill.solid()
    cell.fill.fore_color.rgb = BLACK
    p = cell.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = header
    run.font.size = Pt(10)
    run.font.bold = True
    run.font.color.rgb = WHITE

# Data rows
for i, (signal, desc) in enumerate(signals):
    cell0 = table.cell(i + 1, 0)
    p = cell0.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = signal
    run.font.size = Pt(10)
    run.font.bold = True
    run.font.color.rgb = BLACK
    if i % 2 == 1:
        cell0.fill.solid()
        cell0.fill.fore_color.rgb = LIGHT_GREY

    cell1 = table.cell(i + 1, 1)
    p = cell1.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = desc
    run.font.size = Pt(10)
    run.font.color.rgb = BLACK
    if i % 2 == 1:
        cell1.fill.solid()
        cell1.fill.fore_color.rgb = LIGHT_GREY

# Note
tb = add_textbox(slide, Inches(0.5), table_top + Inches(3.4), Inches(6), Inches(0.6))
tf = tb.text_frame
tf.word_wrap = True
set_text(tf, 'Signal weights automatically adapt based on the rationalisation pattern \u2014 extract patterns boost data signals; consolidation patterns boost comparison signals.', font_size=10, color=DARK_GREY)

add_image_safe(slide, '12-estate-summary.png', Inches(6.8), body_top + Inches(0.2), width=Inches(5.8))


# ============================================================
# SLIDE 8: Persona-Driven Views
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 8)
body_top = add_blue_top_heading(slide, 'Same data, different lens')

add_lead_text(slide, 'Three role-based views over the same estate data, each with different signal emphasis and surface area.', body_top, width=Inches(12))

personas = [
    ('Executive / Transition Board', 'Contract urgency, critical path decisions, pre-vesting triggers. Includes the Critical Path panel.', '08-critical-path.png', BLACK),
    ('Commercial / Transition Director', 'Vendor density, procurement consolidation opportunities, contract timeline visualisation.', '09-persona-commercial.png', GREEN),
    ('Enterprise Architect (CTO)', 'Tech debt, data monoliths, portability risk, TCoP alignment assessment.', '10-persona-architect.png', PURPLE),
]

for i, (title, desc, img, color) in enumerate(personas):
    left = Inches(0.5 + i * 4.2)
    tb = add_textbox(slide, left, body_top + Inches(0.6), Inches(3.8), Inches(0.4))
    set_text(tb.text_frame, title, font_size=14, bold=True, color=color)
    tb = add_textbox(slide, left, body_top + Inches(1.0), Inches(3.8), Inches(0.8))
    tf = tb.text_frame
    tf.word_wrap = True
    set_text(tf, desc, font_size=10, color=DARK_GREY)
    add_image_safe(slide, img, left, body_top + Inches(1.9), width=Inches(3.8))


# ============================================================
# SLIDE 9: Timeline & Critical Path
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 9)
body_top = add_blue_top_heading(slide, 'Contract timeline & critical path')

add_lead_text(slide, 'Every contract across the merging estate, visualised relative to the legal vesting date.', body_top)

items = [
    ('Vesting-centred view', 'the dashed line marks the date successor authorities legally come into existence'),
    ('Notice period zones', 'striped bars show the mandatory notice window; action must be taken before it begins'),
    ('Critical path panel', 'surfaces systems where notice triggers fall before vesting, requiring pre-vesting procurement decisions'),
    ('OVERDUE / URGENT badges', 'systems where the notice deadline has already passed or is imminent'),
    ('Automatic tier promotion', 'a Tier 3 system with a pre-vesting notice trigger is promoted to Tier 2'),
]
add_bullet_list(slide, items, Inches(0.5), body_top + Inches(0.7), Inches(5.8), Inches(3.5))

add_image_safe(slide, '11-timeline.png', Inches(6.8), body_top + Inches(0.2), width=Inches(5.8))


# ============================================================
# SLIDE 10: Demo - The Scenario
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 10)
body_top = add_blue_top_heading(slide, 'In practice: the scenario')

# Tags
add_tag(slide, 'Scenario 3', Inches(0.5), body_top + Inches(0.05), TAG_RED_BG, TAG_RED_FG)
add_tag(slide, 'Shared service unwinding', Inches(2.0), body_top + Inches(0.05), TAG_GREY_BG, TAG_GREY_FG, width=Inches(2.2))

add_lead_text(slide, 'Three councils, two successor authorities. Riverdale and Kingsway share NEC Revenues & Benefits \u2014 one monolithic on-prem database. But LGR sends them to different successors.', body_top + Inches(0.4))

items = [
    ('3 councils \u2192 2 successors', 'Riverdale + Stonebridge form Riverside Council; Kingsway becomes Greater Wolds Council'),
    ('3 shared systems', 'NEC Revenues (monolithic, on-prem, low portability), MHR iTrent, and Civica Elections all serve both Riverdale and Kingsway'),
    ('Vesting date: April 2027', 'the legal date by which all systems must be operational under the new authorities'),
]
add_bullet_list(slide, items, Inches(0.5), body_top + Inches(1.2), Inches(5.8), Inches(2.5))

add_image_safe(slide, 'demo-01-transition.png', Inches(6.8), body_top + Inches(0.2), width=Inches(5.8))


# ============================================================
# SLIDE 11: Demo - Signals Surface Risk
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 11)
body_top = add_blue_top_heading(slide, 'In practice: signals surface risk')

add_lead_text(slide, 'After baselining, the estate summary immediately shows the scale: 27 systems across 3 councils, 9 cross-council collisions, and 7 contracts with pre-vesting notice triggers. \u00a33.16M in annual IT spend needs rationalising.', body_top)

items = [
    ('7 pre-vesting triggers', 'contracts with notice periods that fire before the legal vesting date'),
    ('9 cross-council collisions', 'functions where multiple councils have competing systems'),
    ('Two successor columns', 'the matrix shows each function from both perspectives, with patterns classified per cell'),
]
add_bullet_list(slide, items, Inches(0.5), body_top + Inches(0.9), Inches(5.8), Inches(2.5))

add_image_safe(slide, 'demo-02-matrix.png', Inches(6.8), body_top + Inches(0.2), width=Inches(5.8))


# ============================================================
# SLIDE 12: Demo - Drill into Detail
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 12)
body_top = add_blue_top_heading(slide, 'In practice: the detail')

add_lead_text(slide, 'Click any function row to drill in. The Benefits function has 3 systems in scope, classified as choose & consolidate \u2014 a selection decision is required.', body_top)

items = [
    ('Choose & Consolidate pattern', 'multiple systems from different predecessors serve the same function; one must be selected'),
    ('2 monolithic, 2 on-premise', 'undivided databases requiring data extraction and migration planning'),
    ('Persona-driven key questions', 'the Executive view asks: "What needs to be operational on Day 1?"'),
    ('\u00a3680k annual cost, 283 users', 'key metrics surfaced at a glance for prioritisation'),
]
add_bullet_list(slide, items, Inches(0.5), body_top + Inches(0.7), Inches(5.8), Inches(3.5))

add_image_safe(slide, 'demo-03-detail.png', Inches(6.8), body_top + Inches(0.2), width=Inches(5.8))


# ============================================================
# SLIDE 13: Demo - Timeline Drives Action
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 13)
body_top = add_blue_top_heading(slide, 'In practice: timeline drives action')

add_lead_text(slide, 'The critical path panel surfaces contracts that need decisions before vesting day. The timeline plots every contract against the vesting date.', body_top)

items = [
    ('3 URGENT contracts', 'Access Xpress Electoral, Idox Uniform Planning, and Bartec Collective all trigger before vesting day'),
    ('Vesting day marker', 'the red dashed line anchors every contract decision to the legal transition date'),
    ('Striped notice zones', 'the hatched area shows when the notice window opens; miss it and the contract auto-renews'),
]
add_bullet_list(slide, items, Inches(0.5), body_top + Inches(0.7), Inches(5.8), Inches(2.5))

# Italic note
tb = add_textbox(slide, Inches(0.5), body_top + Inches(3.0), Inches(5.8), Inches(0.5))
tf = tb.text_frame
tf.word_wrap = True
p = tf.paragraphs[0]
run = p.add_run()
run.text = 'Without a consolidated view, this was buried in two separate council spreadsheets.'
run.font.size = Pt(11)
run.font.italic = True
run.font.color.rgb = DARK_GREY

add_image_safe(slide, 'demo-04-timeline.png', Inches(6.8), body_top + Inches(0.2), width=Inches(5.8))


# ============================================================
# SLIDE 14: What Happens Next
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 14)
body_top = add_blue_top_heading(slide, 'In practice: what happens next')

add_lead_text(slide, 'The tool doesn\'t make decisions \u2014 it makes them possible. Here\'s what the transition board might decide, informed by what the engine surfaces.', body_top)

items = [
    ('NEC Revenues: begin procurement now', 'Monolithic, on-prem, low portability, 9-month notice period. Board serves notice immediately and commissions data separation plan.'),
    ('MHR iTrent: negotiate separate instances', 'Shared and monolithic, but medium portability. Approach MHR about splitting to two hosted instances.'),
    ('Civica Elections: extend and split post-vesting', 'Contract ends June 2027, two months after vesting. Negotiate short extension, split in year 1.'),
    ('Stonebridge systems: inherit as-is', 'Clean cloud estate, no shared services. Transfer with no intervention needed.'),
]
add_bullet_list(slide, items, Inches(0.5), body_top + Inches(0.7), Inches(6), Inches(4))

# Quote box
add_quote(slide, 'Four shared systems. Four different strategies \u2014 from immediate procurement to deliberate deferral. Without the consolidated view, the transition board would be working from two separate spreadsheets.',
          '', Inches(6.8), body_top + Inches(0.3), Inches(5.8), border_color=RED)

# Pattern box
shape = add_shape(slide, Inches(6.8), body_top + Inches(2.2), Inches(5.8), Inches(2), fill=LIGHT_GREY)
add_shape(slide, Inches(6.8), body_top + Inches(2.2), Inches(5.8), Inches(0.04), fill=GREEN)
tb = add_textbox(slide, Inches(7.0), body_top + Inches(2.4), Inches(5.4), Inches(0.3))
set_text(tb.text_frame, 'The pattern', font_size=12, bold=True, color=BLACK)
tb = add_textbox(slide, Inches(7.0), body_top + Inches(2.8), Inches(5.4), Inches(1.2))
tf = tb.text_frame
tf.word_wrap = True
set_text(tf, 'Data \u2192 insight \u2192 differentiated action. The same estate produces four distinct procurement strategies, each with a different timeline, risk profile, and cost implication. The tool makes the differences visible so the board can sequence decisions.', font_size=11, color=DARK_GREY)


# ============================================================
# SLIDE 15: Import Wizard
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 15)
body_top = add_blue_top_heading(slide, 'Meeting councils where they are')

add_lead_text(slide, 'Councils have IT estate data in spreadsheets and CMDB exports, not structured architecture files. The import wizard bridges this gap.', body_top)

# Four entry paths heading
tb = add_textbox(slide, Inches(0.5), body_top + Inches(0.7), Inches(5.8), Inches(0.3))
set_text(tb.text_frame, 'Four entry paths', font_size=14, bold=True, color=BLACK)

items = [
    ('Structured JSON upload', 'for councils with mature architecture data already in the engine\'s schema format'),
    ('CSV / Excel upload', 'automatic column detection maps common headers to the engine\'s schema'),
    ('Clipboard paste', 'copy rows directly from a spreadsheet, paste into the wizard'),
    ('Build from scratch', 'guided form-based entry for councils starting with nothing'),
]
add_bullet_list(slide, items, Inches(0.5), body_top + Inches(1.1), Inches(5.8), Inches(2))

tb = add_textbox(slide, Inches(0.5), body_top + Inches(2.9), Inches(5.8), Inches(0.3))
set_text(tb.text_frame, 'ESD function mapping', font_size=14, bold=True, color=BLACK)

tb = add_textbox(slide, Inches(0.5), body_top + Inches(3.3), Inches(5.8), Inches(1))
tf = tb.text_frame
tf.word_wrap = True
set_text(tf, 'The wizard guides users through assigning ESD function IDs \u2014 the critical step that enables cross-council reconciliation. Token-overlap matching auto-suggests functions from department names.', font_size=11, color=DARK_GREY)

add_image_safe(slide, '02-import-wizard.png', Inches(6.8), body_top + Inches(0.2), width=Inches(5.8))


# ============================================================
# SLIDE 16: Grounded in Policy
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 16)
body_top = add_blue_top_heading(slide, 'Operationalising existing guidance')

add_lead_text(slide, 'The tool does not invent methodology. It operationalises what\'s already been published.', body_top, width=Inches(12))

# Left column: relies on
tb = add_textbox(slide, Inches(0.5), body_top + Inches(0.6), Inches(5.8), Inches(0.3))
set_text(tb.text_frame, 'What the tool relies on', font_size=14, bold=True, color=BLACK)

items = [
    ('ESD Standard Function Taxonomy', 'the reconciliation backbone. Without ESD IDs, cross-council comparison is impossible.'),
    ('Local Digital LGR Playbook', 'the tier system maps directly to playbook prioritisation. Baselining data fields align with the tool\'s schema.'),
    ('Technology Code of Practice', 'five TCoP points assessed per-system and surfaced as signals.'),
]
add_bullet_list(slide, items, Inches(0.5), body_top + Inches(1.0), Inches(5.8), Inches(3))

# Right column: reinforces
tb = add_textbox(slide, Inches(6.8), body_top + Inches(0.6), Inches(5.8), Inches(0.3))
set_text(tb.text_frame, 'What the tool reinforces', font_size=14, bold=True, color=BLACK)

items = [
    ('Playbook Theme 3: Collaboration & Baselining', 'the tool IS the structured baselining step the playbook describes'),
    ('Playbook Theme 5: Disaggregation', 'automatically classifies which functions need disaggregation'),
    ('Playbook audience differentiation', 'the three personas directly implement the playbook\'s recognition'),
    ('LGAM (beta)', 'complementary positioning. LGAM defines target-state; this tool analyses current-state'),
]
add_bullet_list(slide, items, Inches(6.8), body_top + Inches(1.0), Inches(5.8), Inches(3.5))


# ============================================================
# SLIDE 17: Framework Alignment Table
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 17)
body_top = add_blue_top_heading(slide, 'Framework alignment')

alignment_data = [
    ('Cross-council baselining', 'Theme 3: "clear shared view of systems"', '\u2014', 'ESD taxonomy reconciliation at Stage 2'),
    ('Tiered prioritisation', 'Tier 1/2/3: statutory first, then by contract urgency', '\u2014', 'Tier badges + automatic promotion when notice triggers pre-vesting'),
    ('Disaggregation analysis', 'Theme 5: data migration, shared service splitting', '\u2014', '4 rationalisation patterns; monolithic data flagging; shared service boundary detection'),
    ('Contract visibility', 'Theme 3: contract end dates and notice periods', '\u2014', 'Vesting-centred timeline; critical path panel; OVERDUE/URGENT badges'),
    ('Audience-appropriate views', 'Different audiences need different information', '\u2014', '3 personas with configurable signal weights'),
    ('Cloud & modern practice', '\u2014', 'Point 5: Cloud first', 'On-premise signal; cloud/on-prem badges'),
    ('Open standards', '\u2014', 'Points 3 & 4: Spend controls, open standards', 'Vendor lock-in risk signal; portability rating'),
    ('Modular architecture', '\u2014', 'Point 9: Modular components', 'Monolithic data signal; ERP flagging'),
    ('Commercial awareness', '\u2014', 'Point 11: Contracts & commercial', 'Vendor density signal; contract urgency; commercial persona'),
]

rows = len(alignment_data) + 1
cols = 4
table = slide.shapes.add_table(rows, cols, Inches(0.5), body_top + Inches(0.1), Inches(12.3), Inches(4.8)).table
table.columns[0].width = Inches(2.5)
table.columns[1].width = Inches(3.3)
table.columns[2].width = Inches(3.0)
table.columns[3].width = Inches(3.5)

headers = ['Capability', 'LGR Playbook', 'Technology Code of Practice', 'Engine implementation']
for j, h in enumerate(headers):
    cell = table.cell(0, j)
    cell.fill.solid()
    cell.fill.fore_color.rgb = BLACK
    p = cell.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = h
    run.font.size = Pt(9)
    run.font.bold = True
    run.font.color.rgb = WHITE

for i, row_data in enumerate(alignment_data):
    for j, text in enumerate(row_data):
        cell = table.cell(i + 1, j)
        if i % 2 == 1:
            cell.fill.solid()
            cell.fill.fore_color.rgb = LIGHT_GREY
        p = cell.text_frame.paragraphs[0]
        run = p.add_run()
        run.text = text
        run.font.size = Pt(8)
        run.font.color.rgb = BLACK
        if j == 0:
            run.font.bold = True


# ============================================================
# SLIDE 18: Benefits & Limitations
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_header_bar(slide, 18)
body_top = add_blue_top_heading(slide, 'Benefits & honest limitations')

# Left: benefits
tb = add_textbox(slide, Inches(0.5), body_top + Inches(0.05), Inches(5.8), Inches(0.3))
set_text(tb.text_frame, 'What it gives you', font_size=14, bold=True, color=GREEN)

benefits = [
    ('Taxonomy-grounded reconciliation', 'two councils calling the same service different names appear in the same row'),
    ('Transition-aware analysis', 'disaggregation patterns classified automatically; systems allocated to successors'),
    ('Role-appropriate views', 'the same estate data, filtered and emphasised for the audience in the room'),
    ('TCoP as a rationalisation lens', 'not just what systems exist, but which align with modern practice'),
    ('Transparent methodology', 'signals are factual observations with configurable weights, not opaque scores'),
    ('Zero-install', 'runs in any browser, no server or dependencies required'),
]
add_bullet_list(slide, benefits, Inches(0.5), body_top + Inches(0.4), Inches(5.8), Inches(4.5))

# Right: limitations
tb = add_textbox(slide, Inches(6.8), body_top + Inches(0.05), Inches(5.8), Inches(0.3))
set_text(tb.text_frame, 'What it doesn\'t do (yet)', font_size=14, bold=True, color=RED)

limitations = [
    ('Data quality is self-reported', 'no validation against source systems; all fields treated as equally reliable'),
    ('No live data connections', 'currently requires manual upload; no CMDB or ServiceNow integration'),
    ('No data confidence scoring', 'no way to mark fields as estimated vs. confirmed'),
    ('ESD taxonomy can be unfamiliar', 'the mapping step remains a cognitive challenge'),
    ('Point-in-time analysis', 'each session starts fresh; no persistent workspace or decision audit trail'),
]
add_bullet_list(slide, limitations, Inches(6.8), body_top + Inches(0.4), Inches(5.8), Inches(4.5))


# ============================================================
# SLIDE 19: Future Direction / End
# ============================================================
slide = prs.slides.add_slide(blank_layout)
add_shape(slide, 0, 0, SLIDE_W, SLIDE_H, fill=BLACK)

# Blue bar
add_shape(slide, Inches(1), Inches(1.0), Inches(1), Inches(0.06), fill=BLUE)

# Title
tb = add_textbox(slide, Inches(1), Inches(1.3), Inches(11), Inches(0.7))
set_text(tb.text_frame, 'Where this could go', font_size=36, bold=True, color=WHITE)

# Subtitle
tb = add_textbox(slide, Inches(1), Inches(2.1), Inches(11), Inches(0.6))
tf = tb.text_frame
tf.word_wrap = True
set_text(tf, 'This is a prototype \u2014 a best-guess implementation of Playbook and TCoP principles. It has not been through discovery, user research, or real-world testing.', font_size=14, color=MID_GREY)

# Future cards
cards = [
    ('The immediate need: validate with real users', 'Test with councils actively going through LGR. Does the ESD taxonomy mapping work in practice? We need discovery and user research before scaling.', GREEN),
    ('If validated: persistent workspaces', 'A persistent workspace so councils can build and refine their baseline over months. Decision annotations create an audit trail.', BLUE),
    ('If validated: deeper modelling', 'Service-level detail (ESD services taxonomy). Cross-cutting capabilities aligned with LGAM. Integration dependency mapping.', BLUE),
    ('If validated: ecosystem connections', 'Live data from CMDBs. Programme board reporting. LGAM target-state overlay.', BLUE),
]

for i, (title, desc, border_color) in enumerate(cards):
    col = i % 2
    row = i // 2
    left = Inches(1 + col * 5.8)
    top = Inches(2.9 + row * 1.8)

    shape = add_shape(slide, left, top, Inches(5.3), Inches(1.5), fill=LIGHT_GREY)
    add_shape(slide, left, top, Inches(5.3), Inches(0.04), fill=border_color)

    tb = add_textbox(slide, left + Inches(0.15), top + Inches(0.15), Inches(5), Inches(0.3))
    set_text(tb.text_frame, title, font_size=12, bold=True, color=BLACK)
    tb = add_textbox(slide, left + Inches(0.15), top + Inches(0.5), Inches(5), Inches(0.9))
    tf = tb.text_frame
    tf.word_wrap = True
    set_text(tf, desc, font_size=10, color=BLACK)

# The ask
tb = add_textbox(slide, Inches(1), Inches(6.6), Inches(11), Inches(0.6))
tf = tb.text_frame
tf.word_wrap = True
set_text(tf, 'The ask: support discovery and user research to validate the approach, with a view to developing this as an official offer for LGR programmes \u2014 whether through GDS, Local Digital, or another route.', font_size=13, color=WHITE)


# ============================================================
# SAVE
# ============================================================
out_path = os.path.join(SLIDE_DIR, 'LGR-Rationalisation-Engine-v1.pptx')
prs.save(out_path)
print(f'Saved: {out_path}')
print(f'{len(prs.slides)} slides')
